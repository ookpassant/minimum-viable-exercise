# minimum-viable-exercise

A Claude skill that makes you do a bit of exercise while it works.

Not a wellness app. Not a coach. Just Claude, mildly judging you for sitting still while it generates your code.

---

## what it does

Whenever Claude starts a task that'll take a moment — code generation, document creation, research, file work — it assigns you one exercise before it begins. When it's done, it asks if you did it. If you didn't, it notes this. Then it gives you the work anyway.

**example:**

> This'll take a moment. Do this now:
>
> **Glute squeezes — 20 reps, 3 second hold each**
> Squeeze both glutes hard, hold for 3 seconds, release fully. Completely invisible. Zero excuses.
> You've been sitting there long enough.

Then when it comes back:

> Did you do them?

If yes: *"Your cardiovascular system is marginally less disappointed in you."*

If no: *"That's between you and your lumbar spine."*

---

## exercise bank

20 exercises across four categories. All office-appropriate, no equipment, no floor work required. Includes form cues for every movement so you're not guessing.

- **chair-based** — leg raises, torso twists, calf raises, neck rolls, glute squeezes
- **standing** — calf raises, shoulder rolls, forward fold, marching on the spot, desk push-ups
- **full movement** — star jumps, squats, push-ups, plank, lunges
- **stretches** — wrist, chest opener, doorframe stretch, hip flexor, side bend

Claude rotates through them and won't repeat the same one twice in a row.

---

## install

1. Download `minimum-viable-exercise.skill`
2. In Claude, go to **Settings → Skills**
3. Click **Install skill** and select the file

That's it. It runs automatically — no commands needed.

---

## tone

Dry. Deadpan. Mildly competitive. Claude is not cheering you on. It is simply noting that you are stationary, and that this is addressable.

It will not be impressed if you do the exercise. It will be unsurprised if you don't.

---

## compatibility

Works with Claude on claude.ai (web, desktop, mobile). Triggers on any task where Claude anticipates a delay. Does not trigger on short answers or quick replies.

---

## contributing

Additional exercises welcome — must be office-appropriate, equipment-free, and accompanied by a form cue. PRs open.

---

*Built with the Claude skill system. No gym membership required.*
